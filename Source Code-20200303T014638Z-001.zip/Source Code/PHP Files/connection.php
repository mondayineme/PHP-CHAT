<?php
$con = mysqli_connect("localhost","root","","mychat") or die("Connection was not established");
?>